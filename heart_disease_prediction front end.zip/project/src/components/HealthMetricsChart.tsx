import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface Props {
  age: number;
  bloodPressure: number;
  cholesterol: number;
  maxHeartRate: number;
}

export function HealthMetricsChart({ age, bloodPressure, cholesterol, maxHeartRate }: Props) {
  const data = {
    labels: ['Age', 'Blood Pressure', 'Cholesterol', 'Max Heart Rate'],
    datasets: [
      {
        label: 'Your Metrics',
        data: [age, bloodPressure, cholesterol / 2, maxHeartRate],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
      },
      {
        label: 'Healthy Range',
        data: [50, 120, 200 / 2, 160],
        borderColor: 'rgb(53, 162, 235)',
        backgroundColor: 'rgba(53, 162, 235, 0.5)',
      },
    ],
  };

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
      title: {
        display: true,
        text: 'Health Metrics Comparison',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  return <Line options={options} data={data} />;
}
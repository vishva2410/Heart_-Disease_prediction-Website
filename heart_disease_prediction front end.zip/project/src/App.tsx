import React, { useState, useEffect } from 'react';
import { Heart, Activity, AlertCircle, Loader2 } from 'lucide-react';
import { loadModel, predict, ModelInput } from './ml/model';
import { HealthMetricsChart } from './components/HealthMetricsChart';
import { validateHealthData, ValidationError } from './utils/validation';

interface FormData {
  age: number;
  sex: string;
  cp: string;
  trestbps: number;
  chol: number;
  fbs: boolean;
  restecg: string;
  thalach: number;
  exang: boolean;
  oldpeak: number;
  slope: string;
  ca: number;
  thal: string;
}

const initialFormData: FormData = {
  age: 45,
  sex: 'male',
  cp: 'typical',
  trestbps: 120,
  chol: 200,
  fbs: false,
  restecg: 'normal',
  thalach: 150,
  exang: false,
  oldpeak: 0,
  slope: 'upsloping',
  ca: 0,
  thal: 'normal'
};

function App() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [prediction, setPrediction] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [modelLoaded, setModelLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);

  useEffect(() => {
    async function initModel() {
      const success = await loadModel();
      setModelLoaded(success);
    }
    initModel();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : 
                    type === 'number' ? (value === '' ? '' : parseFloat(value)) : 
                    value;
    
    setFormData(prev => ({
      ...prev,
      [name]: newValue
    }));

    // Clear errors when user starts typing
    setError(null);
    setValidationErrors([]);
  };

  const mapFormDataToModelInput = (data: FormData): ModelInput => ({
    age: data.age,
    sex: data.sex === 'male' ? 1 : 0,
    cp: ['typical', 'atypical', 'non-anginal', 'asymptomatic'].indexOf(data.cp),
    trestbps: data.trestbps,
    chol: data.chol,
    fbs: data.fbs ? 1 : 0,
    restecg: ['normal', 'st-t-abnormality', 'lv-hypertrophy'].indexOf(data.restecg),
    thalach: data.thalach,
    exang: data.exang ? 1 : 0,
    oldpeak: data.oldpeak,
    slope: ['upsloping', 'flat', 'downsloping'].indexOf(data.slope),
    ca: data.ca,
    thal: ['normal', 'fixed-defect', 'reversible-defect'].indexOf(data.thal)
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setValidationErrors([]);

    // Validate inputs
    const errors = validateHealthData({
      age: formData.age,
      trestbps: formData.trestbps,
      chol: formData.chol,
      thalach: formData.thalach,
      oldpeak: formData.oldpeak,
      ca: formData.ca
    });

    if (errors.length > 0) {
      setValidationErrors(errors);
      setLoading(false);
      return;
    }

    try {
      const modelInput = mapFormDataToModelInput(formData);
      const result = await predict(modelInput);
      setPrediction(result);
    } catch (err) {
      setError('Failed to generate prediction. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getRiskLevel = (prob: number) => {
    if (prob < 0.3) return { text: 'Low Risk', color: 'text-green-600', bg: 'bg-green-100' };
    if (prob < 0.7) return { text: 'Moderate Risk', color: 'text-yellow-600', bg: 'bg-yellow-100' };
    return { text: 'High Risk', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const getHealthAdvice = (prob: number) => {
    if (prob < 0.3) {
      return [
        "Maintain a healthy lifestyle",
        "Regular exercise (150 minutes/week)",
        "Balanced diet rich in fruits and vegetables",
        "Regular health check-ups"
      ];
    } else if (prob < 0.7) {
      return [
        "Consult with your healthcare provider",
        "Monitor blood pressure regularly",
        "Reduce sodium intake",
        "Increase physical activity",
        "Consider stress management techniques"
      ];
    } else {
      return [
        "Seek immediate medical consultation",
        "Strict monitoring of vital signs",
        "Follow prescribed medication regimen",
        "Lifestyle modifications essential",
        "Regular cardiac check-ups"
      ];
    }
  };

  const getFieldError = (fieldName: string) => {
    return validationErrors.find(error => error.field === fieldName)?.message;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Heart className="w-12 h-12 text-red-500 mr-4" />
            <h1 className="text-4xl font-bold text-gray-800">Heart Disease Risk Predictor</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Enter your health information below to get an AI-powered assessment of your heart disease risk.
            Our machine learning model analyzes multiple factors to provide a comprehensive risk evaluation.
          </p>
        </header>

        <div className="max-w-6xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:flex-1 p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Age</label>
                    <input
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleInputChange}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${
                        getFieldError('age') ? 'border-red-300' : 'border-gray-300'
                      }`}
                    />
                    {getFieldError('age') && (
                      <p className="mt-1 text-sm text-red-600">{getFieldError('age')}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Sex</label>
                    <select
                      name="sex"
                      value={formData.sex}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Chest Pain Type</label>
                    <select
                      name="cp"
                      value={formData.cp}
                      onChange={handleInputChange}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                    >
                      <option value="typical">Typical Angina</option>
                      <option value="atypical">Atypical Angina</option>
                      <option value="non-anginal">Non-anginal Pain</option>
                      <option value="asymptomatic">Asymptomatic</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Resting Blood Pressure (mm Hg)</label>
                    <input
                      type="number"
                      name="trestbps"
                      value={formData.trestbps}
                      onChange={handleInputChange}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${
                        getFieldError('trestbps') ? 'border-red-300' : 'border-gray-300'
                      }`}
                    />
                    {getFieldError('trestbps') && (
                      <p className="mt-1 text-sm text-red-600">{getFieldError('trestbps')}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Cholesterol (mg/dl)</label>
                    <input
                      type="number"
                      name="chol"
                      value={formData.chol}
                      onChange={handleInputChange}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${
                        getFieldError('chol') ? 'border-red-300' : 'border-gray-300'
                      }`}
                    />
                    {getFieldError('chol') && (
                      <p className="mt-1 text-sm text-red-600">{getFieldError('chol')}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700">Maximum Heart Rate</label>
                    <input
                      type="number"
                      name="thalach"
                      value={formData.thalach}
                      onChange={handleInputChange}
                      className={`mt-1 block w-full rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 ${
                        getFieldError('thalach') ? 'border-red-300' : 'border-gray-300'
                      }`}
                    />
                    {getFieldError('thalach') && (
                      <p className="mt-1 text-sm text-red-600">{getFieldError('thalach')}</p>
                    )}
                  </div>
                </div>

                {validationErrors.length > 0 && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-md">
                    <p className="text-red-700 font-medium">Please correct the following errors:</p>
                    <ul className="mt-2 text-sm text-red-600 list-disc list-inside">
                      {validationErrors.map((error, index) => (
                        <li key={index}>{error.message}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex items-center justify-center">
                  <button
                    type="submit"
                    disabled={loading || !modelLoaded || validationErrors.length > 0}
                    className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transform transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                  >
                    {loading && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
                    Calculate Risk
                  </button>
                </div>

                {error && (
                  <div className="text-red-600 text-center">
                    {error}
                  </div>
                )}
              </form>
            </div>

            {prediction !== null && (
              <div className="md:flex-1 bg-gray-50 p-8 border-l border-gray-200">
                <div className="text-center">
                  <h2 className="text-2xl font-semibold text-gray-800 mb-4">Risk Assessment</h2>
                  <div className={`inline-block rounded-full p-8 ${getRiskLevel(prediction).bg}`}>
                    <span className={`text-4xl font-bold ${getRiskLevel(prediction).color}`}>
                      {(prediction * 100).toFixed(1)}%
                    </span>
                  </div>
                  <p className={`mt-4 text-xl font-medium ${getRiskLevel(prediction).color}`}>
                    {getRiskLevel(prediction).text}
                  </p>

                  <div className="mt-8">
                    <h3 className="text-lg font-semibold mb-4">Your Health Metrics</h3>
                    <HealthMetricsChart
                      age={formData.age}
                      bloodPressure={formData.trestbps}
                      cholesterol={formData.chol}
                      maxHeartRate={formData.thalach}
                    />
                  </div>

                  <div className="mt-8">
                    <h3 className="text-lg font-semibold mb-4">Recommendations</h3>
                    <ul className="space-y-2 text-left">
                      {getHealthAdvice(prediction).map((advice, index) => (
                        <li key={index} className="flex items-start">
                          <span className="mr-2">•</span>
                          <span>{advice}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="mt-8 p-4 bg-white rounded-lg shadow-sm">
                    <div className="flex items-center text-gray-600">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      <p className="text-sm">
                        This is an AI-generated estimate based on the provided data. Always consult with a healthcare professional for proper medical advice.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <footer className="mt-12 text-center text-gray-600">
          <div className="flex items-center justify-center space-x-2">
            <Activity className="w-5 h-5" />
            <p>Powered by Machine Learning</p>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default App;
import * as tf from '@tensorflow/tfjs';

export interface ModelInput {
  age: number;
  sex: number; // 1 for male, 0 for female
  cp: number; // chest pain type (0-3)
  trestbps: number; // resting blood pressure
  chol: number; // cholesterol
  fbs: number; // fasting blood sugar > 120 mg/dl (1 = true; 0 = false)
  restecg: number; // resting electrocardiographic results (0-2)
  thalach: number; // maximum heart rate achieved
  exang: number; // exercise induced angina (1 = yes; 0 = no)
  oldpeak: number; // ST depression induced by exercise relative to rest
  slope: number; // slope of the peak exercise ST segment (0-2)
  ca: number; // number of major vessels colored by fluoroscopy (0-3)
  thal: number; // thalassemia (0-2)
}

let model: tf.LayersModel | null = null;

export async function loadModel() {
  try {
    // Create a simple model for testing
    model = tf.sequential({
      layers: [
        tf.layers.dense({ inputShape: [13], units: 64, activation: 'relu' }),
        tf.layers.dense({ units: 32, activation: 'relu' }),
        tf.layers.dense({ units: 1, activation: 'sigmoid' })
      ]
    });
    
    // Compile the model
    model.compile({
      optimizer: 'adam',
      loss: 'binaryCrossentropy',
      metrics: ['accuracy']
    });
    
    return true;
  } catch (error) {
    console.error('Error loading model:', error);
    return false;
  }
}

export async function predict(input: ModelInput): Promise<number> {
  if (!model) {
    throw new Error('Model not loaded');
  }

  try {
    // Normalize input values
    const normalizedInput = tf.tensor2d([[
      input.age / 100,
      input.sex,
      input.cp / 3,
      input.trestbps / 200,
      input.chol / 600,
      input.fbs,
      input.restecg / 2,
      input.thalach / 220,
      input.exang,
      input.oldpeak / 6,
      input.slope / 2,
      input.ca / 3,
      input.thal / 2
    ]]);

    const prediction = model.predict(normalizedInput) as tf.Tensor;
    const probability = await prediction.data();
    
    normalizedInput.dispose();
    prediction.dispose();

    return probability[0];
  } catch (error) {
    console.error('Prediction error:', error);
    throw new Error('Failed to make prediction');
  }
}
export interface ValidationError {
  field: string;
  message: string;
}

export function validateHealthData(data: {
  age: number;
  trestbps: number;
  chol: number;
  thalach: number;
  oldpeak: number;
  ca: number;
}): ValidationError[] {
  const errors: ValidationError[] = [];

  // Age validation (20-100 years)
  if (data.age < 20 || data.age > 100) {
    errors.push({
      field: 'age',
      message: 'Age must be between 20 and 100 years'
    });
  }

  // Blood pressure validation (60-300 mmHg)
  if (data.trestbps < 60 || data.trestbps > 300) {
    errors.push({
      field: 'trestbps',
      message: 'Blood pressure must be between 60 and 300 mmHg'
    });
  }

  // Cholesterol validation (100-600 mg/dl)
  if (data.chol < 100 || data.chol > 600) {
    errors.push({
      field: 'chol',
      message: 'Cholesterol must be between 100 and 600 mg/dl'
    });
  }

  // Heart rate validation (60-220 bpm)
  if (data.thalach < 60 || data.thalach > 220) {
    errors.push({
      field: 'thalach',
      message: 'Maximum heart rate must be between 60 and 220 bpm'
    });
  }

  // ST depression validation (0-6.2)
  if (data.oldpeak < 0 || data.oldpeak > 6.2) {
    errors.push({
      field: 'oldpeak',
      message: 'ST depression must be between 0 and 6.2'
    });
  }

  // Number of vessels validation (0-3)
  if (!Number.isInteger(data.ca) || data.ca < 0 || data.ca > 3) {
    errors.push({
      field: 'ca',
      message: 'Number of vessels must be between 0 and 3'
    });
  }

  return errors;
}